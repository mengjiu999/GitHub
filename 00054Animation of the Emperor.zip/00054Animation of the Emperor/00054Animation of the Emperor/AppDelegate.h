//
//  AppDelegate.h
//  00054Animation of the Emperor
//
//  Created by apple on 2018/2/6.
//  Copyright © 2018年 YuNuo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

