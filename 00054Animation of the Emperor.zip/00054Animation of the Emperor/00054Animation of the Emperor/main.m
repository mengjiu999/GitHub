//
//  main.m
//  00054Animation of the Emperor
//
//  Created by apple on 2018/2/6.
//  Copyright © 2018年 YuNuo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
         UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
